package com.example.ottoplay.JavaFiles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.*;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.example.ottoplay.Connectors.*;
import com.example.ottoplay.Models.*;
import com.example.ottoplay.R;
import com.spotify.sdk.android.auth.*;
import android.os.Bundle;
import android.util.Log;

public class SpotifyAuthenticateActivity extends AppCompatActivity {

    private static final String CLIENT_ID = "4ffa67263c5747e182a197afbad6ecc0";
    private static final String REDIRECT_URI = "com.example.ottoplay://callback/";
    private static final int REQUEST_CODE = 1337;
    private static final String SCOPES = "user-read-recently-played," +
            "user-library-modify," +
            "user-read-email," +
            "user-read-private," +
            "playlist-read-private";
    private SharedPreferences.Editor sharedPreferencesEditor;
    private SharedPreferences mySharedPreferences;
    private RequestQueue myRequestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.plsylist_activity_splash);
        spotifyAuthentication();
        mySharedPreferences = this.getSharedPreferences("SPOTIFY", 0);
        myRequestQueue = Volley.newRequestQueue(this);
    }
    private void spotifyAuthentication() {
        AuthorizationRequest.Builder authRequestBuilder = new AuthorizationRequest.Builder(CLIENT_ID, AuthorizationResponse.Type.TOKEN, REDIRECT_URI);
        authRequestBuilder.setScopes(new String[]{SCOPES});
        AuthorizationRequest request = authRequestBuilder.build();
        AuthorizationClient.openLoginActivity(this, REQUEST_CODE, request);
    }

    private void startPlaylistsActivity() {
        Intent newintent = new Intent(SpotifyAuthenticateActivity.this, PlaylistActivity.class);
        startActivity(newintent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == REQUEST_CODE) {
            AuthorizationResponse response = AuthorizationClient.getResponse(resultCode, intent);
            switch (response.getType()) {
                case TOKEN:
                    sharedPreferencesEditor = getSharedPreferences("SPOTIFY", 0).edit();
                    sharedPreferencesEditor.putString("token", response.getAccessToken());
                    Log.d("STARTING", "GOT AUTH TOKEN");
                    sharedPreferencesEditor.apply();
                    getUserInfo();
                    break;
                case ERROR:
                    break;
                default:
            }
        }
    }
    private void getUserInfo() {
        UserService userService = new UserService(myRequestQueue, mySharedPreferences);
        userService.get(() -> {
            UserModel userModel = userService.getUserModel();
            sharedPreferencesEditor = getSharedPreferences("SPOTIFY", 0).edit();
            sharedPreferencesEditor.putString("userid", userModel.id);
            Log.d("STARTING", "GOT USER INFORMATION");
            sharedPreferencesEditor.apply();
            startPlaylistsActivity();
        });
    }


}