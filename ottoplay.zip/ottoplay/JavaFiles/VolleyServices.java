package com.example.ottoplay.JavaFiles;

public interface VolleyServices {
    void onSuccess();
}