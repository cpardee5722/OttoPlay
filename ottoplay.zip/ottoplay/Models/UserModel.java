package com.example.ottoplay.Models;

public class UserModel {

    public String id;
}