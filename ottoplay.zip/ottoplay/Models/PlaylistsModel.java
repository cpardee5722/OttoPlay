package com.example.ottoplay.Models;

public class PlaylistsModel {
    private String id;
    private String name;

    public PlaylistsModel(String id, String name) {
        this.name = name;
        this.id = id;
    }

    public String getPlaylistName() {
        return name;
    }
    public String getPlaylistId() {
        return id;
    }

    public void setPlaylistName(String name) {
        this.name = name;
    }


}
