package com.example.ottoplay.Models;

public class SongModel
{

    private String id,name;


    public SongModel(String id, String name) {
        this.name = name;
        this.id = id;
    }
    public String getSongName() {
        return name;
    }
    public String getSongId() {
        return id;
    }

}