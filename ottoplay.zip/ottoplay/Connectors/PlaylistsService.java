package com.example.ottoplay.Connectors;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import org.json.*;
import java.util.*;
import com.example.ottoplay.JavaFiles.*;
import com.example.ottoplay.Models.PlaylistsModel;
import com.android.volley.*;
import com.android.volley.toolbox.*;


public class PlaylistsService {
    private ArrayList<PlaylistsModel> playlists = new ArrayList<>();
    private SharedPreferences mySharedPreferences;
    private RequestQueue myQueue;

    public PlaylistsService(Context context)
    {
        mySharedPreferences = context.getSharedPreferences("SPOTIFY", 0);
        myQueue = Volley.newRequestQueue(context);
    }

    public ArrayList<PlaylistsModel> getPlaylists()
    {
        return playlists;
    }

    public ArrayList<PlaylistsModel> getUsersPlaylists(final VolleyServices volleyServices)
    {

        String endpoint = "https://api.spotify.com/v1/me/playlists";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, endpoint, null, response -> {
                    Gson gson = new Gson();
                    JSONArray responseArray = response.optJSONArray("items");
                    for (int n = 0; n < responseArray.length(); n++) {
                        try {
                            JSONObject object = responseArray.getJSONObject(n);
                            PlaylistsModel playlist = gson.fromJson(object.toString(), PlaylistsModel.class);
                            playlists.add(playlist);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    volleyServices.onSuccess();
                }, error -> {
                    // TODO: Handle error
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                String token = mySharedPreferences.getString("token", "");
                String auth = "Bearer " + token;
                headers.put("Authorization", auth);
                return headers;
            }
        };
        myQueue.add(jsonObjectRequest);
        return playlists;
    }
}