package com.example.ottoplay.Connectors;

import android.content.SharedPreferences;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.example.ottoplay.JavaFiles.*;
import com.example.ottoplay.Models.*;
import com.google.gson.Gson;
import java.util.*;

public class UserService
{
    private static final String ENDPOINT = "https://api.spotify.com/v1/me";
    private UserModel userModel;
    private SharedPreferences mySharedPreferences;
    private RequestQueue myRequestQueue;

    public UserService(RequestQueue queue, SharedPreferences sharedPreferences)
    {
        myRequestQueue = queue;
        mySharedPreferences = sharedPreferences;
    }


    public void get(final VolleyServices callBack) {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(ENDPOINT, null, response -> {
            Gson gson = new Gson();
            userModel = gson.fromJson(response.toString(), UserModel.class);
            callBack.onSuccess();
        }, error -> get(() -> {
        })) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                String token = mySharedPreferences.getString("token", "");
                String auth = "Bearer " + token;
                headers.put("Authorization", auth);
                return headers;
            }
        };
        myRequestQueue.add(jsonObjectRequest);
    }

    public UserModel getUserModel() {

        return userModel;
    }

}