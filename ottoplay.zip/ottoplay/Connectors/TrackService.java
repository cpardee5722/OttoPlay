package com.example.ottoplay.Connectors;

import android.content.*;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.example.ottoplay.Models.SongModel;
import com.example.ottoplay.JavaFiles.VolleyServices;
import com.google.gson.Gson;
import org.json.*;
import java.util.*;

public class TrackService {
    private String playlistId;
    private ArrayList<SongModel> songs = new ArrayList<>();
    private SharedPreferences sharedPreferences;
    private RequestQueue queue;

    public void setPlaylistId(String playlistId)
    {
        this.playlistId=playlistId;
    }

    public TrackService(Context context) {
        sharedPreferences = context.getSharedPreferences("SPOTIFY", 0);
        queue = Volley.newRequestQueue(context);
    }

    public ArrayList<SongModel> getPlaylistSongs(String playlistId) {
        return songs;
    }

    public ArrayList<SongModel> getPlaylistSongs(final VolleyServices callBack) {

        String start="https://api.spotify.com/v1/playlists/";
        String endpoint = (start.concat(playlistId)).concat("/tracks");//4oc7P1XPr7bkZ0pXysB4aX/tracks";
        System.out.println("Endpoint url is"+endpoint);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, endpoint, null, response -> {
                    Gson gson = new Gson();
                    JSONArray jsonArray = response.optJSONArray("items");
                    for (int n = 0; n < jsonArray.length(); n++) {
                        try {
                            JSONObject object = jsonArray.getJSONObject(n);
                            object = object.optJSONObject("track");
                            SongModel song = gson.fromJson(object.toString(), SongModel.class);
                            songs.add(song);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    callBack.onSuccess();
                }, error -> {
                    // TODO: Handle error
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                String token = sharedPreferences.getString("token", "");
                String auth = "Bearer " + token;
                headers.put("Authorization", auth);
                return headers;
            }
        };
        queue.add(jsonObjectRequest);
        return songs;
    }
}